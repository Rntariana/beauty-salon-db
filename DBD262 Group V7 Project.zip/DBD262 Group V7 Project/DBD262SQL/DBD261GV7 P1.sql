
/*
    #######################
    BEAUTY SALON DATABASE

    22 TABLES:
    1.  Branches
    2.  EmployeeRoles
    3.  Employees
    4.  EmployeeSchedules
    5.  Clients
    6.  ServiceCategories
    7.  Services
    8.  ServicePackages
    9.  PackageServices
    10. Appointments
    11. AppointmentServices
    12. PaymentMethods
    13. Payments
    14. ProductCategories
    15. Suppliers
    16. Products
    17. PurchaseOrders
    18. PurchaseOrderItems
    19. Inventory
    20. Promotions
    21. ClientReviews
    22. EmployeeServices
    ######################
*/
--     =======================1. PHYSICAL DATABASE IMPLEMENTATION=======================

CREATE DATABASE BeautySalonDB;
GO

USE BeautySalonDB;
GO

    -- 1. BRANCHES

CREATE TABLE dbo.Branches
(
    BranchID INT IDENTITY(1,1) NOT NULL,
    BranchName VARCHAR(100) NOT NULL,
    AddressLine1 VARCHAR(150) NOT NULL,
    City VARCHAR(50) NOT NULL,
    Province VARCHAR(50) NULL,
    PostalCode VARCHAR(10) NULL,
    PhoneNumber VARCHAR(20) NOT NULL,
    Email VARCHAR(100) NULL,
    OpeningTime TIME NOT NULL,
    ClosingTime TIME NOT NULL,

    CONSTRAINT PK_Branches
        PRIMARY KEY (BranchID),

    CONSTRAINT UQ_Branches_BranchName
        UNIQUE (BranchName),

    CONSTRAINT CK_Branches_OpeningHours
        CHECK (ClosingTime > OpeningTime)
);
GO

    --2. EMPLOYEE ROLES

CREATE TABLE dbo.EmployeeRoles
(
    RoleID INT IDENTITY(1,1) NOT NULL,
    RoleName VARCHAR(50) NOT NULL,
    RoleDescription VARCHAR(200) NULL,
    BaseHourlyRate DECIMAL(8,2) NULL,

    CONSTRAINT PK_EmployeeRoles
        PRIMARY KEY (RoleID),

    CONSTRAINT UQ_EmployeeRoles_RoleName
        UNIQUE (RoleName),

    CONSTRAINT CK_EmployeeRoles_BaseHourlyRate
        CHECK (BaseHourlyRate IS NULL OR BaseHourlyRate >= 0)
);
GO

    --3. EMPLOYEES

CREATE TABLE dbo.Employees
(
    EmployeeID INT IDENTITY(1,1) NOT NULL,
    BranchID INT NOT NULL,
    RoleID INT NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    HireDate DATE NOT NULL
        CONSTRAINT DF_Employees_HireDate DEFAULT CONVERT(DATE, GETDATE()),
    EmploymentStatus VARCHAR(20) NOT NULL
        CONSTRAINT DF_Employees_EmploymentStatus DEFAULT 'Active',
    CommissionRate DECIMAL(5,2) NOT NULL
        CONSTRAINT DF_Employees_CommissionRate DEFAULT 0,

    CONSTRAINT PK_Employees
        PRIMARY KEY (EmployeeID),

    CONSTRAINT UQ_Employees_Email
        UNIQUE (Email),

    CONSTRAINT FK_Employees_Branches
        FOREIGN KEY (BranchID)
        REFERENCES dbo.Branches(BranchID),

    CONSTRAINT FK_Employees_EmployeeRoles
        FOREIGN KEY (RoleID)
        REFERENCES dbo.EmployeeRoles(RoleID),

    CONSTRAINT CK_Employees_EmploymentStatus
        CHECK (EmploymentStatus IN ('Active', 'OnLeave', 'Terminated')),

    CONSTRAINT CK_Employees_CommissionRate
        CHECK (CommissionRate BETWEEN 0 AND 100)
);
GO

    --4. EMPLOYEE SCHEDULES

CREATE TABLE dbo.EmployeeSchedules
(
    ScheduleID INT IDENTITY(1,1) NOT NULL,
    EmployeeID INT NOT NULL,
    WorkDate DATE NOT NULL,
    ShiftStart TIME NOT NULL,
    ShiftEnd TIME NOT NULL,

    CONSTRAINT PK_EmployeeSchedules
        PRIMARY KEY (ScheduleID),

    CONSTRAINT FK_EmployeeSchedules_Employees
        FOREIGN KEY (EmployeeID)
        REFERENCES dbo.Employees(EmployeeID),

    CONSTRAINT CK_EmployeeSchedules_ShiftTime
        CHECK (ShiftEnd > ShiftStart),

    CONSTRAINT UQ_EmployeeSchedules
        UNIQUE (EmployeeID, WorkDate, ShiftStart)
);
GO

    --5. CLIENTS

CREATE TABLE dbo.Clients
(
    ClientID INT IDENTITY(1,1) NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NULL,
    Phone VARCHAR(20) NOT NULL,
    DateOfBirth DATE NULL,
    Gender VARCHAR(20) NULL,
    RegistrationDate DATE NOT NULL
        CONSTRAINT DF_Clients_RegistrationDate DEFAULT CONVERT(DATE, GETDATE()),
    PreferredBranchID INT NULL,
    Notes VARCHAR(500) NULL,

    CONSTRAINT PK_Clients
        PRIMARY KEY (ClientID),

    CONSTRAINT UQ_Clients_Email
        UNIQUE (Email),

    CONSTRAINT UQ_Clients_Phone
        UNIQUE (Phone),

    CONSTRAINT FK_Clients_Branches
        FOREIGN KEY (PreferredBranchID)
        REFERENCES dbo.Branches(BranchID)
);
GO

    --6. SERVICE CATEGORIES

CREATE TABLE dbo.ServiceCategories
(
    CategoryID INT IDENTITY(1,1) NOT NULL,
    CategoryName VARCHAR(50) NOT NULL,
    Description VARCHAR(200) NULL,

    CONSTRAINT PK_ServiceCategories
        PRIMARY KEY (CategoryID),

    CONSTRAINT UQ_ServiceCategories_CategoryName
        UNIQUE (CategoryName)
);
GO

    --7. SERVICES

CREATE TABLE dbo.Services
(
    ServiceID INT IDENTITY(1,1) NOT NULL,
    CategoryID INT NOT NULL,
    ServiceName VARCHAR(100) NOT NULL,
    Description VARCHAR(300) NULL,
    DurationMinutes INT NOT NULL,
    Price DECIMAL(8,2) NOT NULL,
    IsActive BIT NOT NULL
        CONSTRAINT DF_Services_IsActive DEFAULT 1,

    CONSTRAINT PK_Services
        PRIMARY KEY (ServiceID),

    CONSTRAINT FK_Services_ServiceCategories
        FOREIGN KEY (CategoryID)
        REFERENCES dbo.ServiceCategories(CategoryID),

    CONSTRAINT CK_Services_Duration
        CHECK (DurationMinutes > 0),

    CONSTRAINT CK_Services_Price
        CHECK (Price >= 0)
);
GO

    --8. SERVICE PACKAGES

CREATE TABLE dbo.ServicePackages
(
    PackageID INT IDENTITY(1,1) NOT NULL,
    PackageName VARCHAR(100) NOT NULL,
    Description VARCHAR(300) NULL,
    PackagePrice DECIMAL(8,2) NOT NULL,
    IsActive BIT NOT NULL
        CONSTRAINT DF_ServicePackages_IsActive DEFAULT 1,

    CONSTRAINT PK_ServicePackages
        PRIMARY KEY (PackageID),

    CONSTRAINT CK_ServicePackages_Price
        CHECK (PackagePrice >= 0)
);
GO

/*
    9. PACKAGE SERVICES
    Junction table: ServicePackages M:N Services
*/

CREATE TABLE dbo.PackageServices
(
    PackageID INT NOT NULL,
    ServiceID INT NOT NULL,

    CONSTRAINT PK_PackageServices
        PRIMARY KEY (PackageID, ServiceID),

    CONSTRAINT FK_PackageServices_ServicePackages
        FOREIGN KEY (PackageID)
        REFERENCES dbo.ServicePackages(PackageID),

    CONSTRAINT FK_PackageServices_Services
        FOREIGN KEY (ServiceID)
        REFERENCES dbo.Services(ServiceID)
);
GO

    --10. APPOINTMENTS

CREATE TABLE dbo.Appointments
(
    AppointmentID INT IDENTITY(1,1) NOT NULL,
    ClientID INT NOT NULL,
    EmployeeID INT NOT NULL,
    BranchID INT NOT NULL,
    AppointmentDate DATE NOT NULL,
    StartTime TIME NOT NULL,
    EndTime TIME NOT NULL,
    Status VARCHAR(20) NOT NULL
        CONSTRAINT DF_Appointments_Status DEFAULT 'Booked',
    CreatedAt DATETIME NOT NULL
        CONSTRAINT DF_Appointments_CreatedAt DEFAULT GETDATE(),
    Notes VARCHAR(300) NULL,

    CONSTRAINT PK_Appointments
        PRIMARY KEY (AppointmentID),

    CONSTRAINT FK_Appointments_Clients
        FOREIGN KEY (ClientID)
        REFERENCES dbo.Clients(ClientID),

    CONSTRAINT FK_Appointments_Employees
        FOREIGN KEY (EmployeeID)
        REFERENCES dbo.Employees(EmployeeID),

    CONSTRAINT FK_Appointments_Branches
        FOREIGN KEY (BranchID)
        REFERENCES dbo.Branches(BranchID),

    CONSTRAINT CK_Appointments_Time
        CHECK (EndTime > StartTime),

    CONSTRAINT CK_Appointments_Status
        CHECK (Status IN ('Booked', 'Completed', 'Cancelled', 'NoShow'))
);
GO

/*
    11. APPOINTMENT SERVICES
    Junction-like line-item table:
    One row represents either a service OR a package.
*/

CREATE TABLE dbo.AppointmentServices
(
    AppointmentServiceID INT IDENTITY(1,1) NOT NULL,
    AppointmentID INT NOT NULL,
    ServiceID INT NULL,
    PackageID INT NULL,
    Price DECIMAL(8,2) NOT NULL,

    CONSTRAINT PK_AppointmentServices
        PRIMARY KEY (AppointmentServiceID),

    CONSTRAINT FK_AppointmentServices_Appointments
        FOREIGN KEY (AppointmentID)
        REFERENCES dbo.Appointments(AppointmentID),

    CONSTRAINT FK_AppointmentServices_Services
        FOREIGN KEY (ServiceID)
        REFERENCES dbo.Services(ServiceID),

    CONSTRAINT FK_AppointmentServices_ServicePackages
        FOREIGN KEY (PackageID)
        REFERENCES dbo.ServicePackages(PackageID),

    CONSTRAINT CK_AppointmentServices_Price
        CHECK (Price >= 0),

    CONSTRAINT CK_AppointmentServices_ServiceOrPackage
        CHECK
        (
            (ServiceID IS NOT NULL AND PackageID IS NULL)
            OR
            (ServiceID IS NULL AND PackageID IS NOT NULL)
        )
);
GO

    --12. PAYMENT METHODS

CREATE TABLE dbo.PaymentMethods
(
    PaymentMethodID INT IDENTITY(1,1) NOT NULL,
    MethodName VARCHAR(30) NOT NULL,

    CONSTRAINT PK_PaymentMethods
        PRIMARY KEY (PaymentMethodID),

    CONSTRAINT UQ_PaymentMethods_MethodName
        UNIQUE (MethodName)
);
GO

    --13. PAYMENTS

CREATE TABLE dbo.Payments
(
    PaymentID INT IDENTITY(1,1) NOT NULL,
    AppointmentID INT NOT NULL,
    PaymentMethodID INT NOT NULL,
    Amount DECIMAL(8,2) NOT NULL,
    TipAmount DECIMAL(8,2) NOT NULL
        CONSTRAINT DF_Payments_TipAmount DEFAULT 0,
    PaymentDate DATETIME NOT NULL
        CONSTRAINT DF_Payments_PaymentDate DEFAULT GETDATE(),
    Status VARCHAR(20) NOT NULL
        CONSTRAINT DF_Payments_Status DEFAULT 'Paid',

    CONSTRAINT PK_Payments
        PRIMARY KEY (PaymentID),

    CONSTRAINT FK_Payments_Appointments
        FOREIGN KEY (AppointmentID)
        REFERENCES dbo.Appointments(AppointmentID),

    CONSTRAINT FK_Payments_PaymentMethods
        FOREIGN KEY (PaymentMethodID)
        REFERENCES dbo.PaymentMethods(PaymentMethodID),

    CONSTRAINT CK_Payments_Amount
        CHECK (Amount > 0),

    CONSTRAINT CK_Payments_Tip
        CHECK (TipAmount >= 0),

    CONSTRAINT CK_Payments_Status
        CHECK (Status IN ('Paid', 'Refunded', 'Pending'))
);
GO

    --14. PRODUCT CATEGORIES

CREATE TABLE dbo.ProductCategories
(
    CategoryID INT IDENTITY(1,1) NOT NULL,
    CategoryName VARCHAR(50) NOT NULL,
    Description VARCHAR(200) NULL,

    CONSTRAINT PK_ProductCategories
        PRIMARY KEY (CategoryID),

    CONSTRAINT UQ_ProductCategories_CategoryName
        UNIQUE (CategoryName)
);
GO

    --15. SUPPLIERS

CREATE TABLE dbo.Suppliers
(
    SupplierID INT IDENTITY(1,1) NOT NULL,
    SupplierName VARCHAR(100) NOT NULL,
    ContactPerson VARCHAR(100) NULL,
    Phone VARCHAR(20) NULL,
    Email VARCHAR(100) NULL,
    AddressLine1 VARCHAR(150) NULL,

    CONSTRAINT PK_Suppliers
        PRIMARY KEY (SupplierID)
);
GO

    --16. PRODUCTS

CREATE TABLE dbo.Products
(
    ProductID INT IDENTITY(1,1) NOT NULL,
    CategoryID INT NOT NULL,
    SupplierID INT NOT NULL,
    ProductName VARCHAR(100) NOT NULL,
    Brand VARCHAR(50) NULL,
    UnitPrice DECIMAL(8,2) NOT NULL,
    ReorderLevel INT NOT NULL
        CONSTRAINT DF_Products_ReorderLevel DEFAULT 5,
    IsActive BIT NOT NULL
        CONSTRAINT DF_Products_IsActive DEFAULT 1,

    CONSTRAINT PK_Products
        PRIMARY KEY (ProductID),

    CONSTRAINT FK_Products_ProductCategories
        FOREIGN KEY (CategoryID)
        REFERENCES dbo.ProductCategories(CategoryID),

    CONSTRAINT FK_Products_Suppliers
        FOREIGN KEY (SupplierID)
        REFERENCES dbo.Suppliers(SupplierID),

    CONSTRAINT CK_Products_UnitPrice
        CHECK (UnitPrice >= 0),

    CONSTRAINT CK_Products_ReorderLevel
        CHECK (ReorderLevel >= 0)
);
GO

    --17. PURCHASE ORDERS

CREATE TABLE dbo.PurchaseOrders
(
    PurchaseOrderID INT IDENTITY(1,1) NOT NULL,
    SupplierID INT NOT NULL,
    BranchID INT NOT NULL,
    OrderDate DATE NOT NULL
        CONSTRAINT DF_PurchaseOrders_OrderDate DEFAULT CONVERT(DATE, GETDATE()),
    ExpectedDeliveryDate DATE NULL,
    Status VARCHAR(20) NOT NULL
        CONSTRAINT DF_PurchaseOrders_Status DEFAULT 'Pending',

    CONSTRAINT PK_PurchaseOrders
        PRIMARY KEY (PurchaseOrderID),

    CONSTRAINT FK_PurchaseOrders_Suppliers
        FOREIGN KEY (SupplierID)
        REFERENCES dbo.Suppliers(SupplierID),

    CONSTRAINT FK_PurchaseOrders_Branches
        FOREIGN KEY (BranchID)
        REFERENCES dbo.Branches(BranchID),

    CONSTRAINT CK_PurchaseOrders_Status
        CHECK (Status IN ('Pending', 'Received', 'Cancelled')),

    CONSTRAINT CK_PurchaseOrders_DeliveryDate
        CHECK (ExpectedDeliveryDate IS NULL OR ExpectedDeliveryDate >= OrderDate)
);
GO

    --18. PURCHASE ORDER ITEMS

CREATE TABLE dbo.PurchaseOrderItems
(
    PurchaseOrderItemID INT IDENTITY(1,1) NOT NULL,
    PurchaseOrderID INT NOT NULL,
    ProductID INT NOT NULL,
    QuantityOrdered INT NOT NULL,
    UnitCost DECIMAL(8,2) NOT NULL,

    CONSTRAINT PK_PurchaseOrderItems
        PRIMARY KEY (PurchaseOrderItemID),

    CONSTRAINT FK_PurchaseOrderItems_PurchaseOrders
        FOREIGN KEY (PurchaseOrderID)
        REFERENCES dbo.PurchaseOrders(PurchaseOrderID),

    CONSTRAINT FK_PurchaseOrderItems_Products
        FOREIGN KEY (ProductID)
        REFERENCES dbo.Products(ProductID),

    CONSTRAINT CK_PurchaseOrderItems_Quantity
        CHECK (QuantityOrdered > 0),

    CONSTRAINT CK_PurchaseOrderItems_UnitCost
        CHECK (UnitCost >= 0)
);
GO

    --19. INVENTORY

CREATE TABLE dbo.Inventory
(
    InventoryID INT IDENTITY(1,1) NOT NULL,
    ProductID INT NOT NULL,
    BranchID INT NOT NULL,
    QuantityOnHand INT NOT NULL
        CONSTRAINT DF_Inventory_QuantityOnHand DEFAULT 0,
    LastRestockedDate DATE NULL,

    CONSTRAINT PK_Inventory
        PRIMARY KEY (InventoryID),

    CONSTRAINT FK_Inventory_Products
        FOREIGN KEY (ProductID)
        REFERENCES dbo.Products(ProductID),

    CONSTRAINT FK_Inventory_Branches
        FOREIGN KEY (BranchID)
        REFERENCES dbo.Branches(BranchID),

    CONSTRAINT CK_Inventory_Quantity
        CHECK (QuantityOnHand >= 0),

    CONSTRAINT UQ_Inventory_ProductBranch
        UNIQUE (ProductID, BranchID)
);
GO

    --20. PROMOTIONS

CREATE TABLE dbo.Promotions
(
    PromotionID INT IDENTITY(1,1) NOT NULL,
    PromotionName VARCHAR(100) NOT NULL,
    Description VARCHAR(300) NULL,
    ServiceID INT NULL,
    DiscountPercentage DECIMAL(5,2) NOT NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    IsActive BIT NOT NULL
        CONSTRAINT DF_Promotions_IsActive DEFAULT 1,

    CONSTRAINT PK_Promotions
        PRIMARY KEY (PromotionID),

    CONSTRAINT FK_Promotions_Services
        FOREIGN KEY (ServiceID)
        REFERENCES dbo.Services(ServiceID),

    CONSTRAINT CK_Promotions_Discount
        CHECK (DiscountPercentage BETWEEN 0 AND 100),

    CONSTRAINT CK_Promotions_Dates
        CHECK (EndDate >= StartDate)
);
GO

    --21. CLIENT REVIEWS

CREATE TABLE dbo.ClientReviews
(
    ReviewID INT IDENTITY(1,1) NOT NULL,
    ClientID INT NOT NULL,
    AppointmentID INT NOT NULL,
    EmployeeID INT NULL,
    Rating INT NOT NULL,
    Comment VARCHAR(500) NULL,
    ReviewDate DATETIME NOT NULL
        CONSTRAINT DF_ClientReviews_ReviewDate DEFAULT GETDATE(),

    CONSTRAINT PK_ClientReviews
        PRIMARY KEY (ReviewID),

    CONSTRAINT FK_ClientReviews_Clients
        FOREIGN KEY (ClientID)
        REFERENCES dbo.Clients(ClientID),

    CONSTRAINT FK_ClientReviews_Appointments
        FOREIGN KEY (AppointmentID)
        REFERENCES dbo.Appointments(AppointmentID),

    CONSTRAINT FK_ClientReviews_Employees
        FOREIGN KEY (EmployeeID)
        REFERENCES dbo.Employees(EmployeeID),

    CONSTRAINT CK_ClientReviews_Rating
        CHECK (Rating BETWEEN 1 AND 5)
);
GO

/*
    22. EMPLOYEE SERVICES
    Junction table: Employees M:N Services
*/

CREATE TABLE dbo.EmployeeServices
(
    EmployeeID INT NOT NULL,
    ServiceID INT NOT NULL,

    CONSTRAINT PK_EmployeeServices
        PRIMARY KEY (EmployeeID, ServiceID),

    CONSTRAINT FK_EmployeeServices_Employees
        FOREIGN KEY (EmployeeID)
        REFERENCES dbo.Employees(EmployeeID),

    CONSTRAINT FK_EmployeeServices_Services
        FOREIGN KEY (ServiceID)
        REFERENCES dbo.Services(ServiceID)
);
GO

/*
    ###########
    SAMPLE DATA 
    ###########
*/

-- 1. Branches

INSERT INTO dbo.Branches
(
    BranchName,
    AddressLine1,
    City,
    Province,
    PostalCode,
    PhoneNumber,
    Email,
    OpeningTime,
    ClosingTime
)
VALUES
(
    'Beauty Bliss Pretoria',
    '15 Central Street',
    'Pretoria',
    'Gauteng',
    '0002',
    '0123456789',
    'pretoria@beautybliss.co.za',
    '08:00',
    '18:00'
);
GO

-- 2. EmployeeRoles

INSERT INTO dbo.EmployeeRoles
(
    RoleName,
    RoleDescription,
    BaseHourlyRate
)
VALUES
('Stylist', 'Provides hair styling and treatment services', 120.00),
('Nail Technician', 'Provides manicure and nail treatment services', 100.00),
('Beauty Therapist', 'Provides beauty and skincare treatments', 130.00),
('Receptionist', 'Manages bookings and assists clients', 90.00),
('Manager', 'Manages salon staff and branch operations', 180.00);
GO

-- 3. Employees

INSERT INTO dbo.Employees
(
    BranchID,
    RoleID,
    FirstName,
    LastName,
    Email,
    Phone,
    HireDate,
    EmploymentStatus,
    CommissionRate
)
VALUES
(1, 1, 'Lerato', 'Mokoena', 'lerato@beautybliss.co.za',
 '0712345678', '2025-02-01', 'Active', 10.00),

(1, 2, 'Naledi', 'Dlamini', 'naledi@beautybliss.co.za',
 '0723456789', '2025-03-15', 'Active', 8.00),

(1, 4, 'Thandi', 'Nkosi', 'thandi@beautybliss.co.za',
 '0734567890', '2024-11-10', 'Active', 0.00),

(1, 3, 'Anele', 'Mkhize', 'anele@beautybliss.co.za',
 '0745678901', '2025-04-20', 'Active', 12.00);
GO

-- 4. EmployeeSchedules

INSERT INTO dbo.EmployeeSchedules
(
    EmployeeID,
    WorkDate,
    ShiftStart,
    ShiftEnd
)
VALUES
(1, '2026-09-14', '08:00', '16:00'),
(2, '2026-09-14', '09:00', '17:00'),
(3, '2026-09-14', '08:30', '16:30'),
(4, '2026-09-14', '08:00', '17:00');
GO

-- 5. Clients

INSERT INTO dbo.Clients
(
    FirstName,
    LastName,
    Email,
    Phone,
    DateOfBirth,
    Gender,
    RegistrationDate,
    PreferredBranchID,
    Notes
)
VALUES
('Ayanda', 'Ndlovu', 'ayanda@gmail.com', '0761111111',
 '2000-05-12', 'Female', '2026-01-10', 1,
 'Prefers morning appointments'),

('Nomsa', 'Khumalo', 'nomsa@gmail.com', '0762222222',
 '1998-09-21', 'Female', '2026-02-15', 1,
 'Sensitive skin'),

('Sipho', 'Mthembu', 'sipho@gmail.com', '0763333333',
 '1997-11-03', 'Male', '2026-03-01', 1,
 NULL);
GO

-- 6. ServiceCategories

INSERT INTO dbo.ServiceCategories
(
    CategoryName,
    Description
)
VALUES
('Hair', 'Hair styling and treatment services'),
('Nails', 'Manicure and nail treatment services'),
('Skincare', 'Facial and skincare services');
GO

-- 7. Services

INSERT INTO dbo.Services
(
    CategoryID,
    ServiceName,
    Description,
    DurationMinutes,
    Price,
    IsActive
)
VALUES
(1, 'Hair Wash and Blow Dry',
 'Hair wash and blow dry service', 45, 250.00, 1),

(1, 'Hair Treatment',
 'Deep conditioning hair treatment', 60, 350.00, 1),

(2, 'Manicure',
 'Basic manicure service', 45, 180.00, 1),

(2, 'Gel Nails',
 'Gel nail application', 60, 300.00, 1),

(3, 'Facial Treatment',
 'Basic facial skincare treatment', 60, 400.00, 1);
GO

-- 8. ServicePackages

INSERT INTO dbo.ServicePackages
(
    PackageName,
    Description,
    PackagePrice,
    IsActive
)
VALUES
('Hair Care Package',
 'Hair wash, blow dry and treatment package', 550.00, 1),

('Beauty Package',
 'Manicure and facial treatment package', 520.00, 1);
GO

-- 9. PackageServices

INSERT INTO dbo.PackageServices
(
    PackageID,
    ServiceID
)
VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 5);
GO

-- 10. Appointments

INSERT INTO dbo.Appointments
(
    ClientID,
    EmployeeID,
    BranchID,
    AppointmentDate,
    StartTime,
    EndTime,
    Status,
    Notes
)
VALUES
(1, 1, 1, '2026-09-15', '09:00', '10:00',
 'Booked', 'Hair appointment'),

(2, 2, 1, '2026-09-15', '10:30', '11:30',
 'Booked', 'Nail appointment'),

(3, 4, 1, '2026-09-16', '11:00', '12:00',
 'Completed', 'Facial treatment');
GO

-- 11. AppointmentServices

INSERT INTO dbo.AppointmentServices
(
    AppointmentID,
    ServiceID,
    PackageID,
    Price
)
VALUES
(1, 1, NULL, 250.00),
(2, 3, NULL, 180.00),
(3, 5, NULL, 400.00);
GO

-- 12. PaymentMethods

INSERT INTO dbo.PaymentMethods
(
    MethodName
)
VALUES
('Cash'),
('Card'),
('EFT'),
('Mobile Pay');
GO

-- 13. Payments

INSERT INTO dbo.Payments
(
    AppointmentID,
    PaymentMethodID,
    Amount,
    TipAmount,
    Status
)
VALUES
(1, 2, 250.00, 20.00, 'Paid'),
(2, 1, 180.00, 0.00, 'Paid'),
(3, 3, 400.00, 30.00, 'Paid');
GO

-- 14. ProductCategories

INSERT INTO dbo.ProductCategories
(
    CategoryName,
    Description
)
VALUES
('Hair Products', 'Products used for hair care and styling'),
('Nail Products', 'Products used for nail care and treatments'),
('Skincare Products', 'Products used for facial and skincare treatments');
GO

-- 15. Suppliers

INSERT INTO dbo.Suppliers
(
    SupplierName,
    ContactPerson,
    Phone,
    Email,
    AddressLine1
)
VALUES
('Beauty Supply SA', 'Sarah Molefe', '0115551001',
 'sales@beautysupply.co.za', '25 Market Street, Johannesburg'),

('Professional Hair Products', 'John Dlamini', '0125552002',
 'orders@prohair.co.za', '18 Central Avenue, Pretoria'),

('Nail Care Distributors', 'Lindiwe Nkosi', '0105553003',
 'info@nailcare.co.za', '40 Business Road, Midrand');
GO

-- 16. Products

INSERT INTO dbo.Products
(
    CategoryID,
    SupplierID,
    ProductName,
    Brand,
    UnitPrice,
    ReorderLevel,
    IsActive
)
VALUES
(1, 2, 'Moisturising Shampoo', 'ProHair', 120.00, 5, 1),
(1, 2, 'Hair Conditioner', 'ProHair', 130.00, 5, 1),
(2, 3, 'Gel Nail Polish', 'NailPro', 95.00, 10, 1),
(3, 1, 'Facial Cleanser', 'SkinGlow', 150.00, 5, 1);
GO

-- 17. PurchaseOrders

INSERT INTO dbo.PurchaseOrders
(
    SupplierID,
    BranchID,
    OrderDate,
    ExpectedDeliveryDate,
    Status
)
VALUES
(1, 1, '2026-09-10', '2026-09-15', 'Pending'),
(2, 1, '2026-09-11', '2026-09-16', 'Received'),
(3, 1, '2026-09-12', '2026-09-18', 'Pending');
GO

-- 18. PurchaseOrderItems

INSERT INTO dbo.PurchaseOrderItems
(
    PurchaseOrderID,
    ProductID,
    QuantityOrdered,
    UnitCost
)
VALUES
(1, 4, 10, 95.00),
(2, 1, 20, 75.00),
(2, 2, 15, 80.00),
(3, 3, 25, 60.00);
GO

-- 19. Inventory

INSERT INTO dbo.Inventory
(
    ProductID,
    BranchID,
    QuantityOnHand,
    LastRestockedDate
)
VALUES
(1, 1, 20, '2026-09-11'),
(2, 1, 15, '2026-09-11'),
(3, 1, 25, '2026-09-12'),
(4, 1, 12, '2026-09-10');
GO

-- 20. Promotions

INSERT INTO dbo.Promotions
(
    PromotionName,
    Description,
    ServiceID,
    DiscountPercentage,
    StartDate,
    EndDate,
    IsActive
)
VALUES
('Hair Special', 'Discount on hair treatment', 2,
 10.00, '2026-09-01', '2026-09-30', 1),

('Nail Special', 'Discount on gel nails', 4,
 15.00, '2026-09-01', '2026-09-30', 1);
GO

-- 21. ClientReviews

INSERT INTO dbo.ClientReviews
(
    ClientID,
    AppointmentID,
    EmployeeID,
    Rating,
    Comment
)
VALUES
(1, 1, 1, 5, 'Excellent service'),
(2, 2, 2, 4, 'Very happy with the service'),
(3, 3, 4, 5, 'Professional and friendly');
GO

-- 22. EmployeeServices

INSERT INTO dbo.EmployeeServices
(
    EmployeeID,
    ServiceID
)
VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(4, 5);
GO

/*
    #######
    INDEXES
    #######
*/

CREATE INDEX IX_Employees_BranchID
ON dbo.Employees(BranchID);
GO

CREATE INDEX IX_Employees_RoleID
ON dbo.Employees(RoleID);
GO

CREATE INDEX IX_EmployeeSchedules_EmployeeID_WorkDate
ON dbo.EmployeeSchedules(EmployeeID, WorkDate);
GO

CREATE INDEX IX_Clients_PreferredBranchID
ON dbo.Clients(PreferredBranchID);
GO

CREATE INDEX IX_Services_CategoryID
ON dbo.Services(CategoryID);
GO

CREATE INDEX IX_PackageServices_ServiceID
ON dbo.PackageServices(ServiceID);
GO

CREATE INDEX IX_Appointments_AppointmentDate
ON dbo.Appointments(AppointmentDate);
GO

CREATE INDEX IX_Appointments_ClientID
ON dbo.Appointments(ClientID);
GO

CREATE INDEX IX_Appointments_EmployeeID_AppointmentDate
ON dbo.Appointments(EmployeeID, AppointmentDate);
GO

CREATE INDEX IX_Appointments_BranchID_AppointmentDate
ON dbo.Appointments(BranchID, AppointmentDate);
GO

CREATE INDEX IX_AppointmentServices_AppointmentID
ON dbo.AppointmentServices(AppointmentID);
GO

CREATE INDEX IX_AppointmentServices_ServiceID
ON dbo.AppointmentServices(ServiceID);
GO

CREATE INDEX IX_AppointmentServices_PackageID
ON dbo.AppointmentServices(PackageID);
GO

CREATE INDEX IX_Payments_AppointmentID
ON dbo.Payments(AppointmentID);
GO

CREATE INDEX IX_Payments_PaymentMethodID
ON dbo.Payments(PaymentMethodID);
GO

CREATE INDEX IX_Products_CategoryID
ON dbo.Products(CategoryID);
GO

CREATE INDEX IX_Products_SupplierID
ON dbo.Products(SupplierID);
GO

CREATE INDEX IX_PurchaseOrders_SupplierID
ON dbo.PurchaseOrders(SupplierID);
GO

CREATE INDEX IX_PurchaseOrders_BranchID
ON dbo.PurchaseOrders(BranchID);
GO

CREATE INDEX IX_PurchaseOrders_OrderDate
ON dbo.PurchaseOrders(OrderDate);
GO

CREATE INDEX IX_PurchaseOrderItems_ProductID
ON dbo.PurchaseOrderItems(ProductID);
GO

CREATE INDEX IX_Inventory_BranchID
ON dbo.Inventory(BranchID);
GO

CREATE INDEX IX_Promotions_ServiceID
ON dbo.Promotions(ServiceID);
GO

CREATE INDEX IX_ClientReviews_AppointmentID
ON dbo.ClientReviews(AppointmentID);
GO

CREATE INDEX IX_ClientReviews_EmployeeID
ON dbo.ClientReviews(EmployeeID);
GO

CREATE INDEX IX_EmployeeServices_ServiceID
ON dbo.EmployeeServices(ServiceID);
GO

/*
    ============================================================
    VERIFICATION
    ============================================================
*/

-- Verify the number of tables.

SELECT
    COUNT(*) AS TotalTables
FROM sys.tables
WHERE is_ms_shipped = 0;
GO

-- Display all tables.

SELECT
    name AS TableName
FROM sys.tables
WHERE is_ms_shipped = 0
ORDER BY name;
GO

-- Verify indexes.

SELECT
    OBJECT_NAME(object_id) AS TableName,
    name AS IndexName,
    type_desc AS IndexType
FROM sys.indexes
WHERE name IS NOT NULL
ORDER BY TableName, IndexName;
GO

/*
    #####################
    SAFE CONSTRAINT TESTS
    #####################
*/

-- TEST 1: ClientReviews Rating must be between 1 and 5.

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO dbo.ClientReviews
    (
        ClientID,
        AppointmentID,
        EmployeeID,
        Rating,
        Comment
    )
    VALUES
    (1, 1, 1, 7, 'Invalid rating test');

    ROLLBACK TRANSACTION;

    PRINT 'ERROR: Rating constraint did not reject invalid data.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    PRINT 'PASS: ClientReviews rating constraint rejected invalid data.';
    PRINT ERROR_MESSAGE();
END CATCH;
GO

-- TEST 2: Inventory QuantityOnHand cannot be negative.

BEGIN TRY
    BEGIN TRANSACTION;

    UPDATE dbo.Inventory
    SET QuantityOnHand = -5
    WHERE InventoryID = 1;

    ROLLBACK TRANSACTION;

    PRINT 'ERROR: Inventory constraint did not reject invalid data.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    PRINT 'PASS: Inventory quantity constraint rejected invalid data.';
    PRINT ERROR_MESSAGE();
END CATCH;
GO

-- TEST 3: Employees CommissionRate must be between 0 and 100.

BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO dbo.Employees
    (
        BranchID,
        RoleID,
        FirstName,
        LastName,
        Email,
        Phone,
        HireDate,
        EmploymentStatus,
        CommissionRate
    )
    VALUES
    (
        1,
        1,
        'Test',
        'Employee',
        'testemployee@test.com',
        '0700000000',
        '2026-09-13',
        'Active',
        150
    );

    ROLLBACK TRANSACTION;

    PRINT 'ERROR: CommissionRate constraint did not reject invalid data.';
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;

    PRINT 'PASS: CommissionRate constraint rejected invalid data.';
    PRINT ERROR_MESSAGE();
END CATCH;
GO

/*
    #######################
    FINAL DATA VERIFICATION
    #######################
*/

SELECT 'Branches' AS TableName, COUNT(*) AS RecordCount
FROM dbo.Branches
UNION ALL
SELECT 'EmployeeRoles', COUNT(*)
FROM dbo.EmployeeRoles
UNION ALL
SELECT 'Employees', COUNT(*)
FROM dbo.Employees
UNION ALL
SELECT 'EmployeeSchedules', COUNT(*)
FROM dbo.EmployeeSchedules
UNION ALL
SELECT 'Clients', COUNT(*)
FROM dbo.Clients
UNION ALL
SELECT 'ServiceCategories', COUNT(*)
FROM dbo.ServiceCategories
UNION ALL
SELECT 'Services', COUNT(*)
FROM dbo.Services
UNION ALL
SELECT 'ServicePackages', COUNT(*)
FROM dbo.ServicePackages
UNION ALL
SELECT 'PackageServices', COUNT(*)
FROM dbo.PackageServices
UNION ALL
SELECT 'Appointments', COUNT(*)
FROM dbo.Appointments
UNION ALL
SELECT 'AppointmentServices', COUNT(*)
FROM dbo.AppointmentServices
UNION ALL
SELECT 'PaymentMethods', COUNT(*)
FROM dbo.PaymentMethods
UNION ALL
SELECT 'Payments', COUNT(*)
FROM dbo.Payments
UNION ALL
SELECT 'ProductCategories', COUNT(*)
FROM dbo.ProductCategories
UNION ALL
SELECT 'Suppliers', COUNT(*)
FROM dbo.Suppliers
UNION ALL
SELECT 'Products', COUNT(*)
FROM dbo.Products
UNION ALL
SELECT 'PurchaseOrders', COUNT(*)
FROM dbo.PurchaseOrders
UNION ALL
SELECT 'PurchaseOrderItems', COUNT(*)
FROM dbo.PurchaseOrderItems
UNION ALL
SELECT 'Inventory', COUNT(*)
FROM dbo.Inventory
UNION ALL
SELECT 'Promotions', COUNT(*)
FROM dbo.Promotions
UNION ALL
SELECT 'ClientReviews', COUNT(*)
FROM dbo.ClientReviews
UNION ALL
SELECT 'EmployeeServices', COUNT(*)
FROM dbo.EmployeeServices;
GO

--     =======================2. QUERIES AND VIEWS=======================

   --QUERY 1: Upcoming/Recent Appointments

SELECT
    a.AppointmentID,
    c.FirstName + ' ' + c.LastName AS ClientName,
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    b.BranchName,
    a.AppointmentDate,
    a.StartTime,
    a.EndTime,
    a.Status
FROM dbo.Appointments AS a
INNER JOIN dbo.Clients AS c
    ON a.ClientID = c.ClientID
INNER JOIN dbo.Employees AS e
    ON a.EmployeeID = e.EmployeeID
INNER JOIN dbo.Branches AS b
    ON a.BranchID = b.BranchID
ORDER BY
    a.AppointmentDate,
    a.StartTime;

   --QUERY 2: Total Revenue by Payment Method

SELECT
    pm.MethodName,
    COUNT(p.PaymentID) AS NumberOfPayments,
    SUM(p.Amount) AS TotalRevenue
FROM dbo.Payments AS p
INNER JOIN dbo.PaymentMethods AS pm
    ON p.PaymentMethodID = pm.PaymentMethodID
WHERE p.Status = 'Paid'
GROUP BY
    pm.MethodName
ORDER BY
    TotalRevenue DESC;

   --QUERY 3: Products That Need Restocking

SELECT
    p.ProductID,
    p.ProductName,
    p.Brand,
    b.BranchName,
    i.QuantityOnHand,
    p.ReorderLevel
FROM dbo.Inventory AS i
INNER JOIN dbo.Products AS p
    ON i.ProductID = p.ProductID
INNER JOIN dbo.Branches AS b
    ON i.BranchID = b.BranchID
WHERE i.QuantityOnHand <= p.ReorderLevel
ORDER BY
    b.BranchName,
    i.QuantityOnHand;
GO

   --VIEW 1: Appointment Details

CREATE VIEW dbo.vw_AppointmentDetails
AS
SELECT
    a.AppointmentID,
    c.FirstName + ' ' + c.LastName AS ClientName,
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    b.BranchName,
    a.AppointmentDate,
    a.StartTime,
    a.EndTime,
    a.Status,
    a.Notes
FROM dbo.Appointments AS a
INNER JOIN dbo.Clients AS c
    ON a.ClientID = c.ClientID
INNER JOIN dbo.Employees AS e
    ON a.EmployeeID = e.EmployeeID
INNER JOIN dbo.Branches AS b
    ON a.BranchID = b.BranchID;
GO
SELECT *
FROM dbo.vw_AppointmentDetails;
GO

   --VIEW 2: Employee Service List

CREATE VIEW dbo.vw_EmployeeServices
AS
SELECT
    e.EmployeeID,
    e.FirstName + ' ' + e.LastName AS EmployeeName,
    s.ServiceID,
    s.ServiceName,
    sc.CategoryName,
    s.DurationMinutes,
    s.Price
FROM dbo.EmployeeServices AS es
INNER JOIN dbo.Employees AS e
    ON es.EmployeeID = e.EmployeeID
INNER JOIN dbo.Services AS s
    ON es.ServiceID = s.ServiceID
INNER JOIN dbo.ServiceCategories AS sc
    ON s.CategoryID = sc.CategoryID;
GO
SELECT *
FROM dbo.vw_EmployeeServices;
GO

   --VIEW 3: Inventory Status

CREATE VIEW dbo.vw_InventoryStatus
AS
SELECT
    i.InventoryID,
    p.ProductName,
    p.Brand,
    b.BranchName,
    i.QuantityOnHand,
    p.ReorderLevel,
    CASE
        WHEN i.QuantityOnHand <= p.ReorderLevel
            THEN 'Restock Required'
        ELSE 'Stock Available'
    END AS StockStatus
FROM dbo.Inventory AS i
INNER JOIN dbo.Products AS p
    ON i.ProductID = p.ProductID
INNER JOIN dbo.Branches AS b
    ON i.BranchID = b.BranchID;
GO
SELECT *
FROM dbo.vw_InventoryStatus;
GO

--     =======================3. NON-STATIC STORED PROCEDURES, UDF's AND OTHER OBJECTS=======================

/* 
   STORED PROCEDURE 1
   Get appointments for a specific employee on a specific date.
 */

CREATE PROCEDURE dbo.usp_GetEmployeeAppointments
    @EmployeeID INT,
    @AppointmentDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        a.AppointmentID,
        c.FirstName + ' ' + c.LastName AS ClientName,
        e.FirstName + ' ' + e.LastName AS EmployeeName,
        b.BranchName,
        a.AppointmentDate,
        a.StartTime,
        a.EndTime,
        a.Status,
        a.Notes
    FROM dbo.Appointments AS a
    INNER JOIN dbo.Clients AS c
        ON a.ClientID = c.ClientID
    INNER JOIN dbo.Employees AS e
        ON a.EmployeeID = e.EmployeeID
    INNER JOIN dbo.Branches AS b
        ON a.BranchID = b.BranchID
    WHERE a.EmployeeID = @EmployeeID
      AND a.AppointmentDate = @AppointmentDate
    ORDER BY a.StartTime;
END;
GO
EXEC dbo.usp_GetEmployeeAppointments
    @EmployeeID = 4,
    @AppointmentDate = '2026-09-15';
GO


/*
   STORED PROCEDURE 2
   Get inventory information for a branch.
*/

CREATE PROCEDURE dbo.usp_GetBranchInventoryStatus
    @BranchID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.ProductID,
        p.ProductName,
        p.Brand,
        i.QuantityOnHand,
        p.ReorderLevel,

        CASE
            WHEN i.QuantityOnHand = 0
                THEN 'OUT OF STOCK'
            WHEN i.QuantityOnHand <= p.ReorderLevel
                THEN 'REORDER REQUIRED'
            ELSE 'STOCK AVAILABLE'
        END AS StockStatus,

        p.UnitPrice,
        i.QuantityOnHand * p.UnitPrice AS InventoryValue

    FROM dbo.Inventory AS i
    INNER JOIN dbo.Products AS p
        ON i.ProductID = p.ProductID
    WHERE i.BranchID = @BranchID
    ORDER BY
        StockStatus,
        p.ProductName;
END;
GO
EXEC dbo.usp_GetBranchInventoryStatus
    @BranchID = 1;
GO


/*
   STORED PROCEDURE 3
   Calculate revenue generated between two dates.
 */

CREATE PROCEDURE dbo.usp_GetRevenueReport
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    /*IF @EndDate < @StartDate
    BEGIN
        THROW 50001, 'End date cannot be earlier than start date.', 1;
    END;

    SELECT
        COUNT(p.PaymentID) AS NumberOfPayments,
        SUM(p.Amount) AS TotalRevenue,
        SUM(p.TipAmount) AS TotalTips,
        SUM(p.Amount + p.TipAmount) AS TotalRevenueIncludingTips
    FROM dbo.Payments AS p
    WHERE p.PaymentDate >= @StartDate
      AND p.PaymentDate < DATEADD(DAY, 1, @EndDate)
      AND p.Status = 'Paid';
END;*/
BEGIN TRY
    IF @EndDate < @StartDate
    BEGIN
        ;THROW 50001, 'End date cannot be earlier than start date.', 1; -- The ';' before the THROW is because SQL SERVER interprets 'THROW' as 'TRANSACTION', the semi-colon helps SQL SERVER parse the command correctly.
    END;
 
    SELECT
        COUNT(p.PaymentID) AS NumberOfPayments,
        SUM(p.Amount) AS TotalRevenue,
        SUM(p.TipAmount) AS TotalTips,
        SUM(p.Amount + p.TipAmount) AS TotalRevenueIncludingTips
    FROM dbo.Payments AS p
    WHERE p.PaymentDate >= @StartDate
      AND p.PaymentDate < DATEADD(DAY, 1, @EndDate)
      AND p.Status = 'Paid';
END TRY
BEGIN CATCH
    SELECT
        ERROR_NUMBER() AS ErrorNumber,
        ERROR_MESSAGE() AS ErrorMessage,
        ERROR_LINE() AS ErrorLine;
END CATCH;
END
EXEC dbo.usp_GetRevenueReport
    @StartDate = '2026-01-01',
    @EndDate = '2026-12-31';
GO

/* #############################
   USER-DEFINED FUNCTIONS (UDFs)
   ############################# 
*/

   --UDF 1: Calculate discounted price.

CREATE FUNCTION dbo.fn_CalculateDiscountedPrice
(
    @Price DECIMAL(10,2),
    @DiscountPercentage DECIMAL(5,2)
)
RETURNS DECIMAL(10,2)
AS
BEGIN
    RETURN @Price - (@Price * @DiscountPercentage / 100);
END;
GO
SELECT
    ServiceName,
    Price,
    dbo.fn_CalculateDiscountedPrice(Price, 10) AS DiscountedPrice
FROM dbo.Services;
GO

   --UDF 2: Calculate appointment duration.

CREATE FUNCTION dbo.fn_AppointmentDuration
(
    @StartTime TIME,
    @EndTime TIME
)
RETURNS INT
AS
BEGIN
    RETURN DATEDIFF(MINUTE, @StartTime, @EndTime);
END;
GO
SELECT
    AppointmentID,
    StartTime,
    EndTime,
    dbo.fn_AppointmentDuration(StartTime, EndTime) AS DurationMinutes
FROM dbo.Appointments;
GO

   -- UDF 3: Calculate total payment including tip.

CREATE FUNCTION dbo.fn_TotalPayment
(
    @Amount DECIMAL(10,2),
    @TipAmount DECIMAL(10,2)
)
RETURNS DECIMAL(10,2)
AS
BEGIN
    RETURN @Amount + @TipAmount;
END;
GO
SELECT
    PaymentID,
    Amount,
    TipAmount,
    dbo.fn_TotalPayment(Amount, TipAmount) AS TotalPaid
FROM dbo.Payments;
GO



/*
   OTHER OBJECT 1: TRIGGER
   Prevent an appointment from being created with an
   end time that is earlier than or equal to its start time.
 */

CREATE TRIGGER dbo.trg_ValidateAppointmentTime
ON dbo.Appointments
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted
        WHERE EndTime <= StartTime
    )
    BEGIN
        ROLLBACK TRANSACTION;

        THROW 50002,
              'Appointment end time must be later than start time.',
              1;
    END;
END;
GO

/*
   OTHER OBJECT 2: TRIGGER
   Automatically updates inventory when a purchase order
   item is inserted.
 */

CREATE TRIGGER dbo.trg_UpdateInventoryAfterPurchase
ON dbo.PurchaseOrderItems
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE i
    SET
        i.QuantityOnHand = i.QuantityOnHand + inserted.QuantityOrdered,
        i.LastRestockedDate = CAST(GETDATE() AS DATE)
    FROM dbo.Inventory AS i
    INNER JOIN inserted
        ON i.ProductID = inserted.ProductID
    INNER JOIN dbo.PurchaseOrders AS po
        ON po.PurchaseOrderID = inserted.PurchaseOrderID
       AND po.BranchID = i.BranchID;
END;
GO

   --VERIFY CREATED OBJECTS

SELECT
    name AS ObjectName,
    type_desc AS ObjectType
FROM sys.objects
WHERE type IN ('P', 'FN', 'TR')
ORDER BY
    type_desc,
    name;
GO

--     =======================4. CODING STANDARDS=======================
--     (CODING STANDARDS are implemented throughout the database script)

--     =======================5. DATABASE BACKUP =======================

/*SELECT
    SERVERPROPERTY('InstanceDefaultBackupPath') AS DefaultBackupPath;
    Result: C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS02\MSSQL\Backup
*/

BACKUP DATABASE BeautySalonDB
TO DISK = 'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS02\MSSQL\Backup\BeautySalonDB.bak'
WITH
    FORMAT,
    INIT,
    NAME = 'BeautySalonDB-Full Backup',
    DESCRIPTION = 'Full backup of our amazing 5-star Beauty Salon database :)';
GO
